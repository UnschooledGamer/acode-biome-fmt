# AcodeTSTemplate

This is the typescript version of Acode Plugin template 

Read acode plugin [documentation](https://docs.acode.app/) to develop plugin for acode editor.

## Feature

- rich typing for acode and its global api
- typings for acode.require api like:
    - dialog boxes
    - fs api
    - file browser
